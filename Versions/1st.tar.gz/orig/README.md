# mobile-farming
Mobile Farming Solution

Landing HTML page using Bootstrap/jQuery
