-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2017 at 02:33 PM
-- Server version: 5.5.54-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21


INSERT INTO `Menu` (`id`, `label`, `perent`, `sort`) VALUES
(1, 'Resource Tracker', 0, 1),
(2, 'Activity Management', 0, 2),
(3, 'Customer Management', 0, 3),
(4, 'Resource Management', 0, 4),
(5, 'Profile Management', 0, 5);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
