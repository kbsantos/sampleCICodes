<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
	
	public function index()
	{

		$this->load->database();
		$query	 = $this->db->query("Select * from `Menu` Order By `sort`");
		$aResult = json_encode($query->result());
		echo $aResult;
		$this->load->view('home');
	}
}
